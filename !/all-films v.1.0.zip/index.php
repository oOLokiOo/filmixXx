<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FilmiXxX</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>


<?php

function d($arr) {
	echo '<pre style="background-color: #888; color: #FFF; border: 2px solid #000; padding: 10px; font-size: 18px;">';
	var_dump($arr);
	echo '</pre>';
}


$filmix_arr = [];
// not find films
//$filmix_arr['https://filmix-ac.ru/']	 					= array('type' => 'class', 'value' => 'content');
//$filmix_arr['https://filmixca31.kinozi.link/']	= array('type' => 'class', 'value' => 'sect-cont');
//$filmix_arr['https://filmix.movie/'] 						= array('type' => 'id', 'value' => 'dle-content');
//$filmix_arr['https://filmix.gay/']							= array('type' => 'class', 'value' => 'mainContainer');

// wrong encoding
//$filmix_arr['https://filmixplay.me/']	 					= array('type' => 'id', 'value' => 'dle-content');
//$filmix_arr['https://filmixlive.me/']	 					= array('type' => 'class', 'value' => 'conttext');

// all GOOD!
$filmix_arr['https://filmix.pub/']	 						= array('type' => 'id', 'value' => 'myTabContent');
$filmix_arr['https://filmix.sh/']	 							= array('type' => 'class', 'value' => 'content');
$filmix_arr['https://filmix.fan/']	 						= array('type' => 'class', 'value' => 'content');
$filmix_arr['https://filmix.my/']	 							= array('type' => 'id', 'value' => 'dle-content');
$filmix_arr['https://filmix.news/']	 						= array('type' => 'id', 'value' => 'dle-content');
$filmix_arr['https://filmix.day/']	 						= array('type' => 'id', 'value' => 'dle-content');
$filmix_arr['https://filmix.date/']	 						= array('type' => 'id', 'value' => 'dle-content');
$filmix_arr['https://filmix.la/']	 							= array('type' => 'id', 'value' => 'dle-content');
$filmix_arr['https://filmix.quest/']	 					= array('type' => 'id', 'value' => 'dle-content');

//$filmix_arr['https://filmix.red/']			 			= array('type' => 'id', 'value' => '');
//$filmix_arr['https://filmix.top/']			 			= array('type' => 'id', 'value' => '');
//$filmix_arr['https://filmix-ac.online/']			= array('type' => 'id', 'value' => '');
//$filmix_arr['https://filmix.ac/']							= array('type' => 'id', 'value' => '');
//$filmix_arr['https://filmix.ua/']							= array('type' => 'id', 'value' => '');
//$filmix_arr['https://filmix.tv/']			 				= array('type' => 'id', 'value' => '');
//$filmix_arr['https://www.filmix.pro/']				= array('type' => 'id', 'value' => 'dle-content');
//$filmix_arr['https://filmix.fans/']	 					= array('type' => 'class', 'value' => 'content');
//$filmix_arr['https://filmix.ws/'] 						= '' // 404, Connection timed out


//die("!!!FILMIX!!!");
//phpinfo();
//d($filmix_arr);
//echo '<hr />';

$dom = new DomDocument();
//$finder = new DomXPath($dom);

$page = 1;
$films = [];
$all_films_count = 0;

foreach ($filmix_arr as $site_url => $options) {
	//echo ('<b>SITENAME:</b> <a href="'.$site_url.'" target="_blank">'.$site_url.'</a><br />');

	@$dom->loadHTMLFile($site_url);

	$i = 1;
	//echo '<b>PAGE:</b> '.$page.'<br /><br />';

	// .movie-item
	//$films_container = $dom->getElementsByTagName('movie-item');

	foreach($dom->getElementsByTagName('a') as $element) { 
		//d($element->nodeValue);
		//d(explode('.', $element->getAttribute('href')));

		$href = explode('.', $element->getAttribute('href'));
		if (isset($href[2]) && 
			$href[2] == 'html' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != '' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != '...' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != 'стать propro+' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != 'Смотреть онлайн' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != 'Реклама' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != 'Abuse' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != 'Помощь' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != 'Соглашение' && 
			trim(preg_replace('/\s\s+/', '', $element->textContent)) != 'Контакты'
			 ) {
			/*
			d($i);
			d($element->getAttribute('href'));
			d(strip_tags($element->textContent));
			*/

			//strip_tags($element->textContent);
			$textContent = trim(preg_replace('/\s\s+/', '', $element->textContent));
			$films[][$element->getAttribute('href')] = $textContent;

			//echo ('<b>FILM URL:</b> '.$i.') <a href="'.$element->getAttribute('href').'" target="_blank">'.$textContent.'</a><br />');

			//$parent = $element->parentNode;
			//var_dump($parent);

			$i++;
			$all_films_count++;
		}
	}

	//d($films);
	//echo '<br /><br />';
	//d(count($films));

	// 16 films on page
	// now go to - https://filmix.la/page/2/

	//echo '<hr />';
	//$page++;
	// DO redirect!
	/*
	if ($page == 5) {
		// CLEAR - https://filmix.my/
		unset($films['https://filmix.my/pro.html']);
		unset($films['https://filmix.my/advertise.html']);
		unset($films['https://filmix.my/agreement.html']);
		unset($films['https://filmix.my/for-owners.html']);
		unset($films['https://filmix.my/faq.html']);
		unset($films['https://filmix.my/pro.html']);

		// CLEAR - https://filmix.la/
		unset($films['https://filmix.la/filmi/']);
		unset($films['https://filmix.la/seria/']);
		unset($films['https://filmix.la/multfilmy/']);
		unset($films['https://filmix.la/multserialy/']);

		d($films);
		die('LAST PAGE!');
	}
	*/
	//die();
}

?>


  <h1>That Film!</h1>
	<h2>At ZAME!!!</h2>

  <img src="https://mobile.zame-dev.org/gloomy-ii/themes/default/images/background-video.jpg" />
  
  <?php 
		d("ALL FILMS COUNT: " . $all_films_count);
		//d($films);
		
		$rnd = rand(1, count($films)-1);
		d($films[$rnd]);
  ?>
  <script src="scripts.js"></script>
</body>

</html>